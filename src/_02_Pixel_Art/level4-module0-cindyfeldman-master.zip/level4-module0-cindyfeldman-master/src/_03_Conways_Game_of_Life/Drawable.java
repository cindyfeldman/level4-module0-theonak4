package _03_Conways_Game_of_Life;
import java.awt.Graphics;

public interface Drawable {
	public void draw(Graphics g);
}
